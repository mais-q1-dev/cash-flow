﻿using Microsoft.AspNetCore.Routing;

namespace Rodobens.Libs.Api.Endpoints;

public interface IEndpoint
{
    static abstract void Map(IEndpointRouteBuilder app);
}
