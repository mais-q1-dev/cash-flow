﻿using Microsoft.AspNetCore.Builder;

namespace Rodobens.Libs.Api.Endpoints;

public abstract class EndpointGroupMap
{
    public abstract void Map(WebApplication app);
}