﻿using System.Diagnostics.CodeAnalysis;

using Microsoft.AspNetCore.Authorization;
using Microsoft.OpenApi.Models;

using Swashbuckle.AspNetCore.SwaggerGen;

namespace Rodobens.Libs.Api.Swagger;

[ExcludeFromCodeCoverage]
public class SecurityRequirementsOperationFilter : IOperationFilter
{
    internal const string TOKEN_TYPE = "bearer";
    private const string AUTHORIZATION = "Authorization";
    private const string TOKEN_DESCRIPTION = "JWT Authorization header using the Bearer scheme. \r\n\r\nEnter yout token in the text input below.\r\n\r\nExample: \"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9\"";
    private const string UNAUTHORIZED = "401";
    private const string FORBIDDEN = "403";

    public static readonly OpenApiSecurityScheme OAuthScheme = new()
    {
        Reference = new OpenApiReference
        {
            Type = ReferenceType.SecurityScheme,
            Id = TOKEN_TYPE
        },
        Description = TOKEN_DESCRIPTION,
        Name = AUTHORIZATION,
        In = ParameterLocation.Header,
        Type = SecuritySchemeType.Http,
        Scheme = TOKEN_TYPE,
        BearerFormat = "JWT"
    };

    public void Apply(OpenApiOperation operation, OperationFilterContext context)
    {
        var endpointAttributes = context.MethodInfo.DeclaringType!
            .GetCustomAttributes(true)
            .OfType<AuthorizeAttribute>()
            .Select(attr => attr.Policy);

        var requiredScopes = context.MethodInfo
            .GetCustomAttributes(true)
            .OfType<AuthorizeAttribute>()
            .Select(attr => attr.Policy)
            .Union(endpointAttributes)
            .Distinct();

        var containsAuthorizePolicy = context.ApiDescription
            .ActionDescriptor
            .EndpointMetadata
            .OfType<AuthorizeAttribute>()
            .Any();

        if (requiredScopes.Any() || containsAuthorizePolicy)
        {
            if (!operation.Responses.Any(r => r.Key == UNAUTHORIZED))
                operation.Responses.Add(UNAUTHORIZED, new OpenApiResponse { Description = "Unauthorized" });

            if (!operation.Responses.Any(r => r.Key == FORBIDDEN))
                operation.Responses.Add(FORBIDDEN, new OpenApiResponse { Description = "Forbidden" });

            operation.Security = new[] { new OpenApiSecurityRequirement { [OAuthScheme] = Array.Empty<string>() } };
        }
    }
}
