﻿using System.Text.Json.Serialization;
using System.Text.Json;

using Microsoft.Extensions.DependencyInjection;
using Rodobens.Libs.Api.Swagger;
using Microsoft.Extensions.Configuration;
using Microsoft.OpenApi.Models;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http.Json;
using Rodobens.Libs.Api.Middlewares;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Rodobens.Libs.Api.Logging;
using Serilog;
using Rodobens.Libs.Api.Endpoints;

namespace Rodobens.Libs.Api;

public static class HostingExtensions
{
    public static void AddRodobensHost(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        services.Configure<JsonOptions>(options =>
        {
            options.SerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
            options.SerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
            options.SerializerOptions.Converters.Add(new JsonStringEnumConverter());
        });

        services.AddExceptionHandler<GlobalExceptionHandler>();
        services.AddProblemDetails();
        services.AddHttpContextAccessor();


        services.AddCors(options => options
            .AddPolicy("rodobensPolicy", policy =>
                policy.AllowAnyOrigin()
                    .AllowAnyMethod()
                    .AllowAnyHeader()
            ));

        services.AddEndpointsApiExplorer();
        services.AddSwaggerGen(options =>
        {
            var swaggerTitle = configuration["SwaggerConfig:Title"];
            var swaggerDescription = configuration["SwaggerConfig:Description"];
            var swaggerVersions = configuration.GetSection("SwaggerConfig:Versions").Get<string[]>();

            foreach (var version in swaggerVersions!)
            {
                options.SwaggerDoc(version, new OpenApiInfo
                {
                    Title = swaggerTitle,
                    Version = version,
                    Description = swaggerDescription
                });
            }

            options.DocInclusionPredicate((version, apiDesc) =>
                apiDesc.RelativePath!.Contains(version));

            options.OperationFilter<SecurityRequirementsOperationFilter>();
            options.DocumentFilter<SwaggerAddServerUrl>();
            options.DocumentFilter<SwaggerAddEnumDescription>();

            options.AddSecurityDefinition(
                SecurityRequirementsOperationFilter.OAuthScheme.Scheme,
                SecurityRequirementsOperationFilter.OAuthScheme);
        });

        services.TryAddTransient<CorrelationIdMiddleware>();
    }

    public static void UseRodobensConfigure(
        this WebApplication app,
        IConfiguration configuration)
    {
        app.UseSwagger();
        app.UseSwaggerUI(options =>
        {
            var swaggerVersions = configuration.GetSection("SwaggerConfig:Versions").Get<string[]>();

            foreach (var version in swaggerVersions!)
            {
                options.SwaggerEndpoint($"/swagger/{version}/swagger.json", $"Rodobens.Template.Api {version}");
            }

            options.DisplayRequestDuration();
            options.EnableDeepLinking();
            options.ShowExtensions();
            options.ShowCommonExtensions();
        });

        app.UseHttpsRedirection();
        app.UseExceptionHandler();
        app.UseMiddleware<CorrelationIdMiddleware>();

        app.UseCors("rodobensPolicy");
        app.UseSerilogRequestLogging();

        app.MapLogEndpoints();
        app.MapEndpoints();
    }
}
