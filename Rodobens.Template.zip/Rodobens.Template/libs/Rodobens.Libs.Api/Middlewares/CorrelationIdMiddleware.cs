﻿using Microsoft.AspNetCore.Http;

using Serilog.Context;
using Serilog.Events;

namespace Rodobens.Libs.Api.Middlewares;

public sealed class CorrelationIdMiddleware : IMiddleware
{
    private readonly string _correlationIdHeader = "X-Correlation-Id";

    public async Task InvokeAsync(HttpContext context, RequestDelegate next)
    {
        var correlationIdHeader = context.Request.Headers[_correlationIdHeader];

        var correlationId = !string.IsNullOrWhiteSpace(correlationIdHeader)
            ? Guid.Parse(correlationIdHeader.ToString())
            : Guid.NewGuid();

        using (LogContext.PushProperty("CorrelationId", new ScalarValue(correlationId)))
        {
            await next(context);
        }
    }
}