﻿using MediatR;

using Rodobens.Libs.Domain.Results;

namespace Rodobens.Libs.Application.Messaging;

public interface IQuery<TResponse> : IRequest<Result<TResponse>>;
