﻿namespace Rodobens.Libs.Domain.Results;

public enum ErrorType
{
    Validation = 1,
    Business = 2,
    NotFound = 3,
    Conflict = 4
}