﻿namespace Rodobens.Libs.Domain.Clocks;

public interface IDateTimeProvider
{
    public DateTime UtcNow { get; }
}
