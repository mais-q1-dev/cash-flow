﻿using MediatR;

namespace Rodobens.Libs.Domain.Entities;

public interface IDomainEvent : INotification;
