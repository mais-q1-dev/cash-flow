﻿# Rodobens .NET Templates

Model name                                  | Short name                      | Language | Tags                                         | Description
----------------                            | ----------------                | -------- | ------------                                 | -----------
Rodobens Template for Application Solution  | rodobens-template               | C#       | Solution/Web/Api/Worker/Clean Architecture   | A Clean Arch Solution Template for creating a Microsservice with ASP.NET Core

## How to install this template?

**For .NET 8.0**

```shell
dotnet new install rodobens-template
```

## How to use this template?

### Rodobens Template: For Application Solution

```shell
dotnet new rodobens-template -n Rodobens.YourProject -o rodobens-yourproject
```

- 📁 libs (It is temporary)
  - 📁 Rodobens.Libs.Api
  - 📁 Rodobens.Libs.Application
  - 📁 Rodobens.Libs.Domain
- 📁 src
  - 📁 Rodobens.YourProject.Api
  - 📁 Rodobens.YourProject.Application
  - 📁 Rodobens.YourProject.Domain
  - 📁 Rodobens.YourProject.Infrastructure