﻿using Rodobens.Libs.Domain.Clocks;

namespace Rodobens.Template.Infrastructure.Common;

internal sealed class DateTimeProvider : IDateTimeProvider
{
    public DateTime UtcNow => DateTime.UtcNow;
}
