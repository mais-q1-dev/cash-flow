﻿using Microsoft.EntityFrameworkCore;

using Rodobens.Template.Domain.Common;

namespace Rodobens.Template.Infrastructure.OraclePrefix;

public class OraclePrefixDbContext : DbContext, IUnitOfWork
{
    public OraclePrefixDbContext(DbContextOptions<OraclePrefixDbContext> options)
        : base(options) { }

    // Map the entities as shown in the example below and remove this comment.
    // public DbSet<Company> Companies { get; set; } = null!;

    protected override void OnModelCreating(ModelBuilder modelBuilder)
        => modelBuilder.ApplyConfigurationsFromAssembly(typeof(OraclePrefixDbContext).Assembly);
}
