﻿using Microsoft.EntityFrameworkCore;

using Rodobens.Template.Domain.Common;
using Rodobens.Template.Domain.Companies;
using Rodobens.Template.Domain.Products;

namespace Rodobens.Template.Infrastructure.SQLite;

public sealed class SQLiteDbContext : DbContext, IUnitOfWork
{
    public SQLiteDbContext(DbContextOptions<SQLiteDbContext> options)
        : base(options) { }

    public DbSet<Company> Companies { get; set; } = null!;
    public DbSet<Product> Products { get; set; } = null!;

    protected override void OnModelCreating(ModelBuilder modelBuilder)
        => modelBuilder.ApplyConfigurationsFromAssembly(typeof(SQLiteDbContext).Assembly);
}