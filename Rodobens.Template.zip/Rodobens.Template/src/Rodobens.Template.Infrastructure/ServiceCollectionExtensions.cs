﻿#if UseSqlServer2005
using System.Data;
#endif
using System.Data.Common;
#if UseSqlServer2005
using System.Data.Odbc;
#endif

using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Logging;

using Rodobens.Libs.Domain.Clocks;
using Rodobens.Template.Domain.Common;
using Rodobens.Template.Domain.Companies;
using Rodobens.Template.Domain.Products;
using Rodobens.Template.Infrastructure.Common;
using Rodobens.Template.Infrastructure.Companies;
#if UseOracle
using Rodobens.Template.Infrastructure.OraclePrefix;
#endif
#if UsePostgreSQL
using Rodobens.Template.Infrastructure.PostgreSQLPrefix;
#endif
using Rodobens.Template.Infrastructure.Products;
using Rodobens.Template.Infrastructure.SQLite;
#if UseSqlServer
using Rodobens.Template.Infrastructure.SqlServerPrefix;
#endif

using Serilog;

namespace Rodobens.Template.Infrastructure;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddRodobensInfra(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        services.AddInMemoryDatabase();
#if UseSqlServer
        services.AddRodobensSqlServerPrefixDatabase(configuration);
#endif
#if UseSqlServer2005
        services.AddRodobensSqlServer2005PrefixDatabase(configuration);
#endif
#if UsePostgreSQL
        services.AddRodobensPostgreSQLPrefixDatabase(configuration);
#endif
#if UseOracle
        services.AddRodobensOraclePrefixDatabase(configuration);
#endif
        services.AddServices();

        return services;
    }

    private static void AddServices(this IServiceCollection services)
    {
        services.TryAddSingleton<IDateTimeProvider, DateTimeProvider>();
    }

    private static void AddInMemoryDatabase(this IServiceCollection services)
    {
        services.TryAddSingleton<DbConnection>(_ =>
        {
            var connection = new SqliteConnection("DataSource=:memory:");
            connection.Open();
            return connection;
        });

        services.TryAddScoped<SQLiteDbContext>(provider =>
        {
            var connection = provider.GetRequiredService<DbConnection>();
            var optionsBuilder = new DbContextOptionsBuilder<SQLiteDbContext>();

            var options = optionsBuilder
                .UseSqlite(connection)
                .LogTo(
                    log => Log.Information(log),
                    new[] {
                        DbLoggerCategory.Database.Command.Name,
                        DbLoggerCategory.Query.Name,
                        DbLoggerCategory.Database.Transaction.Name
                    },
                    LogLevel.Information
                )
                .EnableDetailedErrors()
                .EnableSensitiveDataLogging()
                .Options;

            var context = new SQLiteDbContext(options: options);
            context.Database.EnsureCreated();

            return context;
        });

        services.TryAddScoped<IUnitOfWork>(sp => sp.GetRequiredService<SQLiteDbContext>());
        services.TryAddScoped<ICompanyRepository, CompanyRepository>();
        services.TryAddScoped<IProductRepository, ProductRepository>();
    }
#if UseSqlServer
    private static void AddRodobensSqlServerPrefixDatabase(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        var connectionStrings = configuration.GetConnectionString("SqlServerPrefixConnection");

        services.AddDbContext<SqlServerPrefixDbContext>((sp, options) =>
        {
            options.UseSqlServer(connectionStrings, options =>
            {
                options.EnableRetryOnFailure(5, TimeSpan.FromSeconds(30), null);
                options.CommandTimeout(180);
            });
        });

        //Map the UoW and repositories interface as shown in the example below and remove this comment.
        //services.TryAddScoped<IUnitOfWork>(sp => sp.GetRequiredService<SqlServerPrefixDbContext>());
        //services.TryAddScoped<ICompanyRepository, CompanyRepository>();
    }
#endif
#if UseSqlServer2005
    private static void AddRodobensSqlServer2005PrefixDatabase(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        services.TryAddScoped<IDbConnection>(sp =>
        {
            var connectionString = configuration.GetConnectionString("SqlServer2005PrefixConnection");
            return new OdbcConnection(connectionString);
        });

        //Map the UoW and repositories interface as shown in the example below and remove this comment.
        //services.TryAddScoped<IUnitOfWork>(sp => sp.GetRequiredService<SqlServer2005PrefixDapperContext>());
        //services.TryAddScoped<IProductRepository, ProductDapperRepository>();
    }
#endif
#if UsePostgreSQL
    private static void AddRodobensPostgreSQLPrefixDatabase(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        var connectionStrings = configuration.GetConnectionString("PostgreSQLPrefix");

        services.AddDbContext<PostgreSQLPrefixDbContext>((sp, options) =>
        {
            options.UseNpgsql(connectionStrings, options =>
            {
                options.EnableRetryOnFailure(5, TimeSpan.FromSeconds(30), null);
                options.CommandTimeout(180);
            });
        });

        //Map the UoW and repositories interface as shown in the example below and remove this comment.
        //services.TryAddScoped<IUnitOfWork>(sp => sp.GetRequiredService<PostgreSQLPrefixDbContext>());
        //services.TryAddScoped<ICompanyRepository, CompanyRepository>();
    }
#endif
#if UseOracle
    private static void AddRodobensOraclePrefixDatabase(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        var connectionStrings = configuration.GetConnectionString("OraclePrefix");

        services.AddDbContext<OraclePrefixDbContext>((sp, options) =>
        {
            options.UseOracle(connectionStrings);
        });

        //Map the UoW and repositories interface as shown in the example below and remove this comment.
        //services.TryAddScoped<IUnitOfWork>(sp => sp.GetRequiredService<OraclePrefixDbContext>());
        //services.TryAddScoped<ICompanyRepository, CompanyRepository>();
    }
#endif
}