﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

using Rodobens.Template.Domain.Companies;

namespace Rodobens.Template.Infrastructure.Companies;

public class CompanyEntityConfiguration : IEntityTypeConfiguration<Company>
{
    public void Configure(EntityTypeBuilder<Company> builder)
    {
        builder.ToTable("Companies");

        builder.HasKey(company => company.Id);

        builder.Property(company => company.Name)
            .IsRequired()
            .HasMaxLength(100);

        builder.Property(company => company.CreatedAt)
            .IsRequired();

        builder.Property(company => company.UpdatedAt);

        builder.HasData(
            new Company(
                Guid.Parse("88cceca7-4aea-4a79-a3d6-8e2f0beda518"),
                "Rodobens",
                DateTime.UtcNow,
                null
            )
        );
    }
}
