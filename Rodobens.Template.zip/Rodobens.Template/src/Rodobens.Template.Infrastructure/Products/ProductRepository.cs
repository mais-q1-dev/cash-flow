﻿using Microsoft.EntityFrameworkCore;

using Rodobens.Template.Domain.Products;
using Rodobens.Template.Infrastructure.SQLite;

namespace Rodobens.Template.Infrastructure.Products;

public class ProductRepository : IProductRepository
{
    private readonly SQLiteDbContext _dbContext;

    public ProductRepository(SQLiteDbContext dbContext)
        => _dbContext = dbContext;

    public async Task AddAsync(Product product, CancellationToken cancellationToken)
        => await _dbContext.Products.AddAsync(product, cancellationToken);

    public async Task<IEnumerable<Product>> GetAll(CancellationToken cancellationToken)
        => await _dbContext.Products
            .AsNoTrackingWithIdentityResolution()
            .OrderBy(product => product.Name)
            .ToListAsync(cancellationToken);
}
