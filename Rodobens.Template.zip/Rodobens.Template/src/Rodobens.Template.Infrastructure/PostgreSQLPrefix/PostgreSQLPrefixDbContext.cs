﻿using Microsoft.EntityFrameworkCore;

using Rodobens.Template.Domain.Common;

namespace Rodobens.Template.Infrastructure.PostgreSQLPrefix;

public class PostgreSQLPrefixDbContext : DbContext, IUnitOfWork
{
    public PostgreSQLPrefixDbContext(DbContextOptions<PostgreSQLPrefixDbContext> options)
        : base(options) { }

    // Map the entities as shown in the example below and remove this comment.
    // public DbSet<Company> Companies { get; set; } = null!;

    protected override void OnModelCreating(ModelBuilder modelBuilder)
        => modelBuilder.ApplyConfigurationsFromAssembly(typeof(PostgreSQLPrefixDbContext).Assembly);
}
