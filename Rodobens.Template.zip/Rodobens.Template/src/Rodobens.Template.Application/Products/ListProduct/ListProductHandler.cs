﻿using Rodobens.Libs.Application.Messaging;
using Rodobens.Libs.Domain.Results;
using Rodobens.Template.Application.Products.Common;
using Rodobens.Template.Domain.Products;

namespace Rodobens.Template.Application.Products.ListProduct;

public sealed class ListProductHandler : IQueryHandler<ListProductQuery, IEnumerable<ProductResponse>>
{
    private readonly IProductRepository _productRepository;

    public ListProductHandler(IProductRepository productRepository)
        => _productRepository = productRepository;

    public async Task<Result<IEnumerable<ProductResponse>>> Handle(
        ListProductQuery request,
        CancellationToken cancellationToken)
    {
        var productList = await _productRepository.GetAll(cancellationToken);
        var productResponseList = productList.
            Select(product => new ProductResponse(
                product.Id,
                product.Name,
                product.Price))
            .ToList();

        return Result.Success(productResponseList ?? Enumerable.Empty<ProductResponse>());
    }
}
