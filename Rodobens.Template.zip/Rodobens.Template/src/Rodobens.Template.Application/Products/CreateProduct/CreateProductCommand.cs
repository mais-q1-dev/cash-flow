﻿using FluentValidation;

using Rodobens.Libs.Application.Messaging;

namespace Rodobens.Template.Application.Products.CreateProduct;

public record CreateProductCommand(
    Guid CompanyId,
    string Name,
    decimal Price) : ICommand<Guid>;

public class CreateProductCommandValidator : AbstractValidator<CreateProductCommand>
{
    public CreateProductCommandValidator()
    {
        RuleFor(cp => cp.CompanyId)
            .NotEmpty().WithErrorCode("Command.CompanyId").WithMessage("Company Id can't be empty");

        RuleFor(cp => cp.Name)
            .NotEmpty().WithErrorCode("Command.Name").WithMessage("Name con't be empty")
            .MaximumLength(100).WithErrorCode("Command.Name").WithMessage("Name must be max 100 characteres");

        RuleFor(cp => cp.Price)
            .NotEmpty().WithErrorCode("Command.Price").WithMessage("Price can't be empty")
            .GreaterThan(0).WithErrorCode("Command.Price").WithMessage("Price must be greater than 0");
    }
}