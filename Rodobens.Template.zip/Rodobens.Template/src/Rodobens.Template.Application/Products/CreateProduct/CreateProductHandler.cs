﻿
using Rodobens.Libs.Application.Messaging;
using Rodobens.Libs.Domain.Clocks;
using Rodobens.Libs.Domain.Results;
using Rodobens.Template.Domain.Common;
using Rodobens.Template.Domain.Companies;
using Rodobens.Template.Domain.Products;

namespace Rodobens.Template.Application.Products.CreateProduct;

public sealed class CreateProductHandler : ICommandHandler<CreateProductCommand, Guid>
{
    private readonly IDateTimeProvider _dateTimeProvider;
    private readonly IUnitOfWork _unitOfWork;
    private readonly IProductRepository _productRepository;
    private readonly ICompanyRepository _companyRepository;

    public CreateProductHandler(
        IDateTimeProvider dateTimeProvider,
        IUnitOfWork unitOfWork,
        IProductRepository productRepository,
        ICompanyRepository companyRepository)
    {
        _dateTimeProvider = dateTimeProvider;
        _unitOfWork = unitOfWork;
        _productRepository = productRepository;
        _companyRepository = companyRepository;
    }

    public async Task<Result<Guid>> Handle(
        CreateProductCommand request,
        CancellationToken cancellationToken)
    {
        var companyExists = await _companyRepository.ExistsAsync(request.CompanyId, cancellationToken);
        if (!companyExists)
            return Result.Failure<Guid>(CompanyError.NotFound);

        var product = new Product(
            request.CompanyId,
            request.Name,
            request.Price,
            _dateTimeProvider.UtcNow);

        await _productRepository.AddAsync(product, cancellationToken);
        await _unitOfWork.SaveChangesAsync(cancellationToken);
        
        return product.Id;
    }
}
