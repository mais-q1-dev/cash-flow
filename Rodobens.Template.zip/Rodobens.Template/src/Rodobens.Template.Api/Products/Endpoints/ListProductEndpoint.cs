﻿using MediatR;

using Rodobens.Libs.Api.Endpoints;
using Rodobens.Libs.Domain.Results;
using Rodobens.Template.Api.Extensions;
using Rodobens.Template.Application.Products.Common;
using Rodobens.Template.Application.Products.ListProduct;

namespace Rodobens.Template.Api.Products.Endpoints;

public class ListProductEndpoint : IEndpoint
{
    public static void Map(IEndpointRouteBuilder app)
    {
        app.MapGet("/", async (
            ISender sender,
            CancellationToken cancellationToken) =>
        {
            var result = await sender.Send(new ListProductQuery(), cancellationToken);
            return result.Match(Results.Ok, CustomResults.Problem);
        })
        .Produces<IEnumerable<ProductResponse>>(StatusCodes.Status200OK)
        .ProducesProblem(StatusCodes.Status422UnprocessableEntity)
        .WithOrder(2)
        .WithOpenApi(operation =>
        {
            operation.Summary = "List registered products";
            operation.Description = "This endpoint returns the list of registered products";
            return operation;
        });
    }
}
