﻿using Rodobens.Libs.Api.Endpoints;
using Rodobens.Template.Api.Products.Endpoints;

namespace Rodobens.Template.Api.Products;

public class ProductsEndpoints : EndpointGroupMap
{
    public override void Map(WebApplication app)
    {
        app
            .MapGroup("v1/products")
            .WithTags("Products")
            .MapEndpoint<ListProductEndpoint>()
            .MapEndpoint<CreateProductEndpoint>();
    }
}
