﻿using Rodobens.Libs.Api;
using Rodobens.Template.Application;
using Rodobens.Template.Infrastructure;

namespace Rodobens.Template.Api.Extensions;

public static class ConfigureServicesExtensions
{
    public static void ConfigureServices(
        this IServiceCollection services,
        ConfigurationManager configuration)
    {
        services.AddRodobensHost(configuration);
        services.AddRodobensApplication(configuration);
        services.AddRodobensInfra(configuration);
    }
}
