﻿using Rodobens.Libs.Domain.Results;

namespace Rodobens.Template.Api.Extensions;

public static class CustomResults
{
    public static IResult Problem(Result result)
    {
        if (result.IsSuccess)
        {
            throw new InvalidOperationException();
        }

        return Results.Problem(
            title: GetTitle(result.Error),
            detail: GetDetail(result.Error),
            type: GetType(result.Error.Type),
            statusCode: GetStatusCode(result.Error.Type),
            extensions: GetErrors(result));

        static string GetTitle(Error error) =>
            error.Type switch
            {
                ErrorType.Validation => "Unprocessable Entity",
                ErrorType.Business => "Unprocessable Entity",
                ErrorType.NotFound => "Not Found",
                ErrorType.Conflict => "Conflict",
                _ => "Server failure"
            };

        static string GetDetail(Error error) =>
            error.Type switch
            {
                ErrorType.Validation => "One or more validation failures have occurred",
                ErrorType.Business => "One or more validation failures have occurred",
                ErrorType.NotFound => "Information not found",
                ErrorType.Conflict => "Conflicts occurred during processing",
                _ => "An unexpected error occurred"
            };

        static string GetType(ErrorType errorType) =>
            errorType switch
            {
                ErrorType.Validation => "https://www.rfc-editor.org/rfc/rfc4918#section-11.2",
                ErrorType.Business => "https://www.rfc-editor.org/rfc/rfc4918#section-11.2",
                ErrorType.NotFound => "https://www.rfc-editor.org/rfc/rfc7231#section-6.5.4",
                ErrorType.Conflict => "https://www.rfc-editor.org/rfc/rfc7231#section-6.5.8",
                _ => "https://www.rfc-editor.org/rfc/rfc7231#section-6.6.1"
            };

        static int GetStatusCode(ErrorType errorType) =>
            errorType switch
            {
                ErrorType.Validation => StatusCodes.Status422UnprocessableEntity,
                ErrorType.Business => StatusCodes.Status422UnprocessableEntity,
                ErrorType.NotFound => StatusCodes.Status404NotFound,
                ErrorType.Conflict => StatusCodes.Status409Conflict,
                _ => StatusCodes.Status500InternalServerError
            };

        static Dictionary<string, object?>? GetErrors(Result result)
            => result.Error is not ValidationError validationError
                ? new Dictionary<string, object?> { { "errors", result.Error } }
                : new Dictionary<string, object?> { { "errors", validationError.Errors } };
    }
}
