﻿using Rodobens.Libs.Api;

namespace Rodobens.Template.Api.Extensions;

public static class AppConfigureExtensions
{
    public static void Configure(this WebApplication app)
    {
        app.UseRodobensConfigure(app.Configuration);
    }
}
