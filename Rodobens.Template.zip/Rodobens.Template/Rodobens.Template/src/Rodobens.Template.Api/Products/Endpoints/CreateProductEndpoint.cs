﻿using MediatR;

using Rodobens.Libs.Api.Endpoints;
using Rodobens.Libs.Domain.Results;
using Rodobens.Template.Api.Extensions;
using Rodobens.Template.Application.Products.CreateProduct;

namespace Rodobens.Template.Api.Products.Endpoints;

public class CreateProductEndpoint : IEndpoint
{
    public static void Map(IEndpointRouteBuilder app)
    {
        app.MapPost("/", async (
            CreateProductCommand request,
            ISender sender,
            CancellationToken cancellationToken) =>
        {
            var result = await sender.Send(request, cancellationToken);
            return result.Match(
                onSuccess: id => Results.Created("", id),
                CustomResults.Problem);
        })
        .Produces<Guid>(StatusCodes.Status201Created)
        .ProducesProblem(StatusCodes.Status422UnprocessableEntity)
        .WithOrder(1)
        .WithOpenApi(operation =>
        {
            operation.Summary = "Create a new product";
            operation.Description = "This endpoint is used to add new products";
            return operation;
        });
    }
}
