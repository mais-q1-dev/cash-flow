﻿using Microsoft.EntityFrameworkCore;

using Rodobens.Template.Domain.Common;

namespace Rodobens.Template.Infrastructure.SqlServerPrefix;

public class SqlServerPrefixDbContext : DbContext, IUnitOfWork
{
    public SqlServerPrefixDbContext(DbContextOptions<SqlServerPrefixDbContext> options)
        : base(options) { }

    // Map the entities as shown in the example below and remove this comment.
    // public DbSet<Company> Companies { get; set; } = null!;

    protected override void OnModelCreating(ModelBuilder modelBuilder)
        => modelBuilder.ApplyConfigurationsFromAssembly(typeof(SqlServerPrefixDbContext).Assembly);
}