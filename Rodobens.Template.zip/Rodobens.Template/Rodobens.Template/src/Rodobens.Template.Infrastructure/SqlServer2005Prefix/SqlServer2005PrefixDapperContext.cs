﻿using System.Data;

using Microsoft.Data.SqlClient;

using Microsoft.Extensions.Configuration;

using Rodobens.Template.Domain.Common;

namespace Rodobens.Template.Infrastructure.SqlServer2005Prefix;

public class SqlServer2005PrefixDapperContext : IUnitOfWork
{
    private readonly string _connectionString;
    private IDbConnection _connection;
    private IDbTransaction _transaction;

    public SqlServer2005PrefixDapperContext(IConfiguration configuration)
    {
        var conn = configuration.GetConnectionString("SqlServer2005PrefixConnection")
            ?? throw new ArgumentNullException("SqlServer2005PrefixConnection not found in appsettings.json");
        _connectionString = conn;
    }

    public IDbConnection Connection
    {
        get
        {
            if (_connection is null)
            {
                _connection = new SqlConnection(_connectionString);
                _connection.Open();
                _transaction = _connection.BeginTransaction();
            }
            
            return _connection;
        }
    }

    public IDbTransaction Transaction => _transaction;

    public async Task<int> SaveChangesAsync(CancellationToken cancellationToken)
    {
        await Task.Run(() => _transaction.Commit(), cancellationToken);
        return 1;
    }
}
