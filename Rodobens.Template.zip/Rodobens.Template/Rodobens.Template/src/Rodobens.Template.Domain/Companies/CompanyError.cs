﻿using Rodobens.Libs.Domain.Results;

namespace Rodobens.Template.Domain.Companies;

public static class CompanyError
{
    public static Error NotFound => Error.NotFound("Company.NotFound", "Company not found");
}
