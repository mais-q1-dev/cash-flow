﻿using System.Diagnostics;

using MediatR;

using Microsoft.Extensions.Logging;

using Rodobens.Libs.Domain.Results;

using Serilog.Context;

namespace Rodobens.Libs.Application.Behaviors;

internal sealed class LoggingPipelineBehavior<TRequest, TResponse>(ILogger<LoggingPipelineBehavior<TRequest, TResponse>> logger)
    : IPipelineBehavior<TRequest, TResponse>
    where TRequest : class
    where TResponse : Result
{
    public async Task<TResponse> Handle(
        TRequest request,
        RequestHandlerDelegate<TResponse> next,
        CancellationToken cancellationToken)
    {
        var eventId = default(EventId);
        var requestName = typeof(TRequest).Name;
        try
        {
            var isDebug = logger.IsEnabled(LogLevel.Debug);

            if (isDebug)
                logger.LogInformation(eventId, "Handling request of type {TypeName} with data {@Data}", requestName, request);
            else
                logger.LogInformation(eventId, "Handling request of type {TypeName}", requestName);

            var sp = Stopwatch.StartNew();
            TResponse response = await next();
            sp.Stop();

            if (response.IsSuccess)
            {
                if (isDebug)
                    logger.LogInformation(eventId, "Handled request of type {TypeName} in {Elapsed} with response {@Data}", requestName, sp.Elapsed, response);
                else
                    logger.LogInformation(eventId, "Handled request of type {TypeName} in {Elapsed}", requestName, sp.Elapsed);
            }
            else
            {
                using (LogContext.PushProperty("Error", response.Error, true))
                {
                    logger.LogError("Handled request of type {TypeName} in {Elapsed} with error", requestName, sp.Elapsed);
                }
            }

            return response;
        }
        catch (Exception ex)
        {
            logger.LogError(
                eventId, 
                ex, 
                "Error on request handling of type {RequestName}", 
                requestName);

            throw;
        }
    }
}

