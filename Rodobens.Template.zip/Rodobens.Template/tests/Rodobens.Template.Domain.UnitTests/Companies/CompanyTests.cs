﻿using FluentAssertions.Execution;
using FluentAssertions;
using Rodobens.Template.Domain.Companies;

namespace Rodobens.Template.Domain.UnitTests.Companies;

public class CompanyTests
{
    [Fact]
    public void Create_ShouldReturnCreateCompany()
    {
        // Arrange
        var companyId = Guid.NewGuid();
        var name = "Company Name";
        var createdAt = DateTime.UtcNow;

        // Act
        var company = Company.Create(companyId, name, createdAt, null);

        // Assert
        using (new AssertionScope())
        {
            company.Id.Should().Be(companyId);
            company.Name.Should().Be(name);
            company.CreatedAt.Should().Be(createdAt);
            company.UpdatedAt.Should().BeNull();
            company.DomainEvents.Should().BeEmpty();
        }
    }

    [Fact]
    public void Create_WithUpdateAt_ShouldReturnCreateCompany()
    {
        // Arrange
        var companyId = Guid.NewGuid();
        var name = "Company Name";
        var createdAt = DateTime.UtcNow.AddDays(-1);
        var updateAt = DateTime.UtcNow;

        // Act
        var company = Company.Create(companyId, name, createdAt, updateAt);

        // Assert
        using (new AssertionScope())
        {
            company.Id.Should().Be(companyId);
            company.Name.Should().Be(name);
            company.CreatedAt.Should().Be(createdAt);
            company.UpdatedAt.Should().Be(updateAt);
            company.DomainEvents.Should().BeEmpty();
        }
    }
}
