﻿using FluentAssertions;
using FluentAssertions.Execution;

using Rodobens.Template.Domain.Products;

namespace Rodobens.Template.Domain.UnitTests.Products;

public class ProductTests
{
    [Fact]
    public void Create_ShouldReturnCreateProduct()
    {
        // Arrange
        var companyId = Guid.NewGuid();
        var name = "Company Name";
        var price = 100M;
        var createdAt = DateTime.UtcNow;

        // Act
        var product = Product.Create(companyId,  name, price, createdAt);

        // Assert
        using (new AssertionScope())
        {
            product.Id.Should().NotBeEmpty();
            product.CompanyId.Should().Be(companyId);
            product.Name.Should().Be(name);
            product.Price.Should().Be(price);
            product.CreatedAt.Should().Be(createdAt);
            product.UpdatedAt.Should().BeNull();
            product.DomainEvents.Should().BeEmpty();
        }
    }
}
