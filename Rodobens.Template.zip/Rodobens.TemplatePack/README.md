﻿# Rodobens .NET Templates

Model name							| Short name                    | Lang | Tags                                       | Description
------------------------------------| ------------------------------| ---- | -------------------------------------------| -----------
Rodobens Lib Template				| rodobens-lib-template         | C#   | Library                                    | A Library Template for creating a .NET Library
Rodobens Template for Microservices	| rodobens-template             | C#   | Solution/Api/WebService/Worker/Clean Arch	| A Clean Arch Solution Template for creating a Microservices with ASP.NET Core
Rodobens Template for Api			| rodobens-template-api         | C#   | Api/Clean Arch								| A Clean Arch Api Template for creating a Api with ASP.NET Core
Rodobens Template for Webservice	| rodobens-template-webservice	| C#   | Webservice/Clean Arch						| A Clean Arch Webservice Template for creating a Webservice with ASP.NET Core
Rodobens Template for Worker		| rodobens-template-worker      | C#   | Worker/Clean Arch							| A Clean Arch Worker Template for creating a Worker with ASP.NET Core

## How to install this template?

**For .NET 8.0**

```shell
dotnet new install rodobens-template
```

## How to use this template?

### Rodobens Template: For Microservice

```shell
dotnet new rodobens-template -n Rodobens.YourProject -o rodobens-yourproject
```

```shell
dotnet new rodobens-template -n Rodobens.YourProject -o rodobens-yourproject
```


- 📁 libs (It is temporary)
  - 📁 Rodobens.Libs.Api
  - 📁 Rodobens.Libs.Application
  - 📁 Rodobens.Libs.Domain
  - 📁 Rodobens.Libs.Events
  - 📁 Rodobens.Libs.Events.MassTransit
- 📁 src
  - 📁 Rodobens.YourProject.Api
  - 📁 Rodobens.YourProject.Application
  - 📁 Rodobens.YourProject.Domain
  - 📁 Rodobens.YourProject.Infrastructure