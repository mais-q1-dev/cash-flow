﻿namespace Rodobens.Libs.Events.MassTransit.Settings;

public enum ETransport
{
    AzureServiceBus = 1,
    RabbitMQ = 2
}