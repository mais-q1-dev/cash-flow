﻿using System.ComponentModel.DataAnnotations;

namespace Rodobens.Libs.Events.MassTransit.Settings;

public sealed record MessageBusSetting
{
    public static readonly string Section = "MessageBus";

    [Required]
    public ETransport Transport { get; init; }
    public RabbitMQSettings RabbitMQ { get; set; } = null!;
    public AzureServiceBusSettings AzureServiceBus { get; set; } = null!;
}

public sealed record RabbitMQSettings
{
    [Required]
    public string Host { get; init; } = string.Empty;
    [Required]
    public string Port { get; init; } = string.Empty;
    [Required]
    public string Username { get; init; } = string.Empty;
    [Required]
    public string Password { get; init; } = string.Empty;
    [Required]
    public string VirtualHost { get; init; } = string.Empty;

    public string ConnectionString =>
        $"amqp://{Username}:{Password}@{Host}:{Port}/{VirtualHost}";
}

public sealed record AzureServiceBusSettings
{
    public string ConnectionString { get; init; } = string.Empty;
}