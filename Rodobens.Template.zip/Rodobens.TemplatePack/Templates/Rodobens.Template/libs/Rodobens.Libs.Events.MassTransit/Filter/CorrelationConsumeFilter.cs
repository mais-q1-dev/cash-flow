﻿using MassTransit;
using Rodobens.Libs.Events.MassTransit.Tracing;

using Serilog.Events;

namespace Rodobens.Libs.Events.MassTransit.Filter;

public class CorrelationConsumeFilter<T> : IFilter<ConsumeContext<T>> where T : class
{
    public Task Send(ConsumeContext<T> context, IPipe<ConsumeContext<T>> next)
    {
        var correlationIdHeader = context.CorrelationId;

        if (correlationIdHeader.HasValue)
        {
            var correlationId = correlationIdHeader.Value;

            Serilog.Context.LogContext.PushProperty("CorrelationId", new ScalarValue(correlationId));
            AsyncStorage<Correlation>.Store(new Correlation { Id = correlationId });
        }

        return next.Send(context);
    }

    public void Probe(ProbeContext context)
    { }
}
