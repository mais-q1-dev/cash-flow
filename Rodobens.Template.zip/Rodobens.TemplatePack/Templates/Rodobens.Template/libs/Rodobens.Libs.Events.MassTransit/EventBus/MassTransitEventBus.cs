﻿using MassTransit;

using Rodobens.Libs.Events.EventBus;

namespace Rodobens.Libs.Events.MassTransit.EventBus;

public class MassTransitEventBus : IEventBus
{
    private readonly IPublishEndpoint _publishEndpoint;
    private readonly IMessageScheduler _messageScheduler;

    public MassTransitEventBus(IPublishEndpoint publishEndpoint, IMessageScheduler messageScheduler)
        => (_publishEndpoint, _messageScheduler) = (publishEndpoint, messageScheduler);

    public async Task PublishAsync<T>(T @event) where T : IntegrationEvent
        => await _publishEndpoint.Publish(@event);

    public async Task SchedulePublishAsync<T>(T @event, TimeSpan delay) where T : IntegrationEvent
        => await _messageScheduler.SchedulePublish(delay, @event);
}
