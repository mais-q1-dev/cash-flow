﻿using System.Reflection;

using MassTransit;

using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;

using Rodobens.Libs.Events.EventBus;
using Rodobens.Libs.Events.MassTransit.EventBus;
using Rodobens.Libs.Events.MassTransit.Filter;
using Rodobens.Libs.Events.MassTransit.Settings;

namespace Rodobens.Libs.Events.MassTransit;

public static class MassTransitExtensions
{
    public static IServiceCollection AddRodobensMessageBus(
        this IServiceCollection services,
        IConfiguration configuration,
        Assembly applicationAssembly)
    {
        var messageBusSetting = new MessageBusSetting();
        configuration.GetSection(MessageBusSetting.Section).Bind(messageBusSetting);

        services.AddMassTransit(config =>
        {
            config.SetKebabCaseEndpointNameFormatter();
            
            config.AddConsumers(applicationAssembly);

            if (messageBusSetting.Transport == ETransport.RabbitMQ)
            {
                config.AddDelayedMessageScheduler();

                config.UsingRabbitMq((context, cfg) =>
                {
                    cfg.UseSendFilter(typeof(CorrelationSendFilter<>), context);
                    cfg.UsePublishFilter(typeof(CorrelationPublishFilter<>), context);
                    cfg.UseConsumeFilter(typeof(CorrelationConsumeFilter<>), context);

                    cfg.ClearSerialization();
                    cfg.UseRawJsonSerializer();

                    cfg.Host(
                        messageBusSetting.RabbitMQ.Host,
                        messageBusSetting.RabbitMQ.VirtualHost, 
                        h =>
                        {
                            h.Username(messageBusSetting.RabbitMQ.Username);
                            h.Password(messageBusSetting.RabbitMQ.Password);
                        });

                    cfg.UseDelayedMessageScheduler();
                    cfg.ConfigureEndpoints(context);
                });
            }
            else if (messageBusSetting.Transport == ETransport.AzureServiceBus)
            {
                config.AddServiceBusMessageScheduler();

                config.UsingAzureServiceBus((context, cfg) =>
                {
                    cfg.UseSendFilter(typeof(CorrelationSendFilter<>), context);
                    cfg.UsePublishFilter(typeof(CorrelationPublishFilter<>), context);
                    cfg.UseConsumeFilter(typeof(CorrelationConsumeFilter<>), context);

                    cfg.ClearSerialization();
                    cfg.UseRawJsonSerializer();

                    cfg.Host(messageBusSetting.AzureServiceBus.ConnectionString);

                    cfg.UseDelayedMessageScheduler();
                    cfg.ConfigureEndpoints(context);
                });
            }
        });

        services.TryAddScoped<IEventBus, MassTransitEventBus>();

        return services;
    }

}
