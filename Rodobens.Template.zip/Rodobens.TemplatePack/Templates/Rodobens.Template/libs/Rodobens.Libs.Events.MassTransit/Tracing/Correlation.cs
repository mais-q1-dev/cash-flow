﻿namespace Rodobens.Libs.Events.MassTransit.Tracing;

public record Correlation
{
    public Guid Id { get; init; }
}