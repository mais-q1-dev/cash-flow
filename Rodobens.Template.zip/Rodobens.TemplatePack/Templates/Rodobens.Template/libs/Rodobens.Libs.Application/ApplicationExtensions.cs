﻿using System.Reflection;

using FluentValidation;

using Microsoft.Extensions.DependencyInjection;

using Rodobens.Libs.Application.Behaviors;

namespace Rodobens.Libs.Application;

public static class ApplicationExtensions
{
    public static void AddRodobensMediatR(
        this IServiceCollection services,
        Assembly applicationAssembly,
        Action<MediatRServiceConfiguration>? action = null)
    {
        services.AddMediatR(configuration =>
        {
            configuration.RegisterServicesFromAssembly(applicationAssembly);

            configuration.AddOpenBehavior(typeof(LoggingPipelineBehavior<,>));
            configuration.AddOpenBehavior(typeof(ValidationPipelineBehavior<,>));

            if (action is not null)
                action(configuration);
        });

        services.AddValidatorsFromAssembly(applicationAssembly);
    }
}
