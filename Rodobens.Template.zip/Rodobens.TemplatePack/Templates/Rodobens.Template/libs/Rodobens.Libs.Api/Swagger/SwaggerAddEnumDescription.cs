﻿using System.Diagnostics.CodeAnalysis;

using Microsoft.OpenApi.Any;
using Microsoft.OpenApi.Models;

using Swashbuckle.AspNetCore.SwaggerGen;

namespace Rodobens.Libs.Api.Swagger;

[ExcludeFromCodeCoverage]
public class SwaggerAddEnumDescription : IDocumentFilter
{
    public void Apply(OpenApiDocument swaggerDoc, DocumentFilterContext context)
    {
        foreach (var property in swaggerDoc.Components
            .Schemas
            .Where(p => p.Value?.Enum?.Count > 0))
        {
            var propertyEnums = property.Value.Enum;
            if (propertyEnums.Any())
            {
                property.Value.Description = DescribeEnum(propertyEnums, property.Key);
            }
        }

        foreach (var pathItem in swaggerDoc.Paths.Values)
        {
            DescribeEnumInPathItem(pathItem.Operations, swaggerDoc);
        }
    }

    private static void DescribeEnumInPathItem(
        IDictionary<OperationType, OpenApiOperation> operations,
        OpenApiDocument swaggerDoc)
    {
        if (operations is null)
            return;

        foreach (var param in operations
            .SelectMany(o => o.Value.Parameters))
        {
            var paramEnum = swaggerDoc.Components
                .Schemas
                .FirstOrDefault(p => p.Key == param.Name);
            if (paramEnum.Value is not null)
            {
                param.Description = DescribeEnum(paramEnum.Value.Enum, paramEnum.Key);
            }
        }
    }

    private static string DescribeEnum(IList<IOpenApiAny> enums, string propertyTypeName)
    {
        var enumType = GetEnumTypeByName(propertyTypeName);
        return enumType is null
            ? string.Empty
            : string.Join(", ", enums.OfType<OpenApiInteger>().Select(e => $"{e.Value} = {Enum.GetName(enumType, e.Value)}"));
    }

    private static Type GetEnumTypeByName(string enumTypeName)
        => AppDomain.CurrentDomain
            .GetAssemblies()
            .SelectMany(e => e.GetTypes())
            .First(e => e.Name.Equals(enumTypeName, StringComparison.OrdinalIgnoreCase));
}
