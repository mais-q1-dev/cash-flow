﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

using Serilog;
using Serilog.Core;
using Serilog.Events;

namespace Rodobens.Libs.Api.Logging;

public static class LoggingExtensions
{
    public static void AddRodobensLogging(
        this ConfigureHostBuilder host,
        LoggingLevelSwitch loggingLevelSwitch,
        Action<LoggerConfiguration>? action = null)
    {
        host.UseSerilog((host, cfg) =>
        {
            var minimumLevel = Enum.TryParse<LogEventLevel>(
                host.Configuration["Serilog:MinimumLevel"],
                true,
                out var logEventLevel)
                ? logEventLevel
                : LogEventLevel.Warning;

            loggingLevelSwitch.MinimumLevel = minimumLevel;

            action?.Invoke(cfg);

            cfg.ReadFrom.Configuration(host.Configuration);
            cfg.MinimumLevel.ControlledBy(loggingLevelSwitch)
              .MinimumLevel.Override("Microsoft", LogEventLevel.Warning)
              .MinimumLevel.Override("Microsoft.Hosting.Lifetime", LogEventLevel.Information)
              .MinimumLevel.Override("HealthChecks", LogEventLevel.Error);

        });
    }

    public static void MapLogEndpoints(this WebApplication app)
    {
        var tags = "Log";

        app.MapPost("v1/log-level-test", (
            ILogger<string> logger,
            string data) =>
        {
            const string TEMPLATE = "[LogEndpoint] Message {data}";
            logger.LogTrace(TEMPLATE, data);
            logger.LogDebug(TEMPLATE, data);
            logger.LogInformation(TEMPLATE, data);
            logger.LogWarning(TEMPLATE, data);
            logger.LogError(TEMPLATE, data);
            logger.LogCritical(TEMPLATE, data);

            return Results.Ok(data);
        })
        .WithTags(tags)
        .WithOpenApi(operation =>
        {
            operation.Summary = "Log the message at all log levels";
            operation.Description = "This endpoint should be used to test logging the message at all log levels (trace, debug, information, warning, error, and critical) according to the configured log level";
            return operation;
        });

        app.MapPost("v1/log-level-change", (
            HttpRequest request,
            [FromServices] LoggingLevelSwitch loggingLevelSwitch,
            string logLevel) =>
        {
            if (!Enum.TryParse<LogEventLevel>(logLevel, out var level))
                return Results.BadRequest("Failed to convert the value of the query string 'loglevel'");

            loggingLevelSwitch.MinimumLevel = level;
            return Results.Ok($"LogLevel changed to {level}");
        })
        .WithTags(tags)
        .WithOpenApi(operation =>
         {
             operation.Summary = "Change the application's log level";
             operation.Description = "This endpoint will change the application's log level, allowing the configuration of the following options: Trace, Debug, Information, Warning, Error, or Critical";
             return operation;
         });
    }
}
