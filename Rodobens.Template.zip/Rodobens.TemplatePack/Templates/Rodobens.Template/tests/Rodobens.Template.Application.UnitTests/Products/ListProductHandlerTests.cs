﻿using Rodobens.Libs.Domain.Results;
using Rodobens.Template.Application.Products.Common;
using Rodobens.Template.Application.Products.ListProduct;
using Rodobens.Template.Domain.Products;

namespace Rodobens.Template.Application.UnitTests.Products;

public class ListProductHandlerTests
{
    private readonly Mock<IProductRepository> _productRepositoryMock;
    private readonly ListProductHandler _handler;

    public ListProductHandlerTests()
    {
        _productRepositoryMock = new Mock<IProductRepository>();

        _handler = new ListProductHandler(_productRepositoryMock.Object);
    }

    [Fact]
    public async Task Handle_ShouldListProducts()
    {
        // Arrange
        var companyId = Guid.NewGuid();
        var productMouse = Product.Create(companyId, "Mouse", 100M, DateTime.UtcNow);
        var productKeyboard = Product.Create(companyId, "Keyboard", 100M, DateTime.UtcNow);
        var cancellationToken = new CancellationToken();

        var products = new List<Product> { productMouse, productKeyboard };
        _productRepositoryMock
            .Setup(x => x.GetAll(cancellationToken))
            .ReturnsAsync(products);

        var request = new ListProductQuery();

        // Act
        var result = await _handler.Handle(request, cancellationToken);

        // Assert
        using (new AssertionScope())
        {
            result.IsSuccess.Should().BeTrue();
            result.Value.Should().BeOfType<List<ProductResponse>>();
            result.Value.Should().BeEquivalentTo([
                new ProductResponse(productMouse.Id, productMouse.Name, productMouse.Price),
                new ProductResponse(productKeyboard.Id, productKeyboard.Name, productKeyboard.Price)
            ]);
        }
    }

    [Fact]
    public async Task Handle_WhenProductsIsEmpty_ShouldReturnEmptyListProducts()
    {
        // Arrange
        var request = new ListProductQuery();

        var cancellationToken = new CancellationToken();

        // Act
        var result = await _handler.Handle(request, cancellationToken);

        // Assert
        using (new AssertionScope())
        {
            result.IsSuccess.Should().BeTrue();
            result.Value.Should().BeEmpty();
        }
    }
}
