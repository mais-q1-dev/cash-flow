﻿using Rodobens.Libs.Domain.Clocks;
using Rodobens.Template.Application.Products.CreateProduct;
using Rodobens.Template.Domain.Common;
using Rodobens.Template.Domain.Companies;
using Rodobens.Template.Domain.Products;

namespace Rodobens.Template.Application.UnitTests.Products;

public class CreateProductHandlerTests
{
    private readonly Mock<IDateTimeProvider> _dateTimeProviderMock;
    private readonly Mock<IUnitOfWork> _unitOfWorkMock;
    private readonly Mock<ICompanyRepository> _companyRepositoryMock;
    private readonly Mock<IProductRepository> _productRepositoryMock;
    private readonly Mock<ILogger<CreateProductHandler>> _loggerMock;
    private readonly CreateProductHandler _handler;

    public CreateProductHandlerTests()
    {
        _dateTimeProviderMock = new Mock<IDateTimeProvider>();
        _unitOfWorkMock = new Mock<IUnitOfWork>();
        _companyRepositoryMock = new Mock<ICompanyRepository>();
        _productRepositoryMock = new Mock<IProductRepository>();
        _loggerMock = new Mock<ILogger<CreateProductHandler>>();

        _handler = new CreateProductHandler(
            _dateTimeProviderMock.Object,
            _unitOfWorkMock.Object,
            _productRepositoryMock.Object,
            _companyRepositoryMock.Object,
            _loggerMock.Object);
    }

    [Fact]
    public async Task Handle_ShouldCreateProduct()
    {
        // Arrange
        var request = new CreateProductCommand(
            Guid.NewGuid(),
            "Product Name",
            100M);

        _dateTimeProviderMock
            .Setup(x => x.UtcNow)
            .Returns(DateTime.UtcNow);
        _companyRepositoryMock
            .Setup(x => x.ExistsAsync(request.CompanyId, default))
            .ReturnsAsync(true);

        var cancellationToken = new CancellationToken();

        // Act
        var result = await _handler.Handle(request, cancellationToken);

        // Assert
        using (new AssertionScope())
        {
            result.IsSuccess.Should().BeTrue();
            result.Value.Should().NotBeEmpty();
            
            _productRepositoryMock.Verify(
                x => x.AddAsync(It.IsAny<Product>(), cancellationToken),
                Times.Once);
            
            _unitOfWorkMock.Verify(
                x => x.SaveChangesAsync(cancellationToken), 
                Times.Once);
        }
    }

    [Fact]
    public async Task Handle_WhenCompanyDoesNotExist_ShouldReturnCompanyNotFound()
    {
        // Arrange
        var request = new CreateProductCommand(
            Guid.NewGuid(),
            "Product Name",
            100M);

        _companyRepositoryMock
            .Setup(x => x.ExistsAsync(request.CompanyId, default))
            .ReturnsAsync(false);

        var cancellationToken = new CancellationToken();

        // Act
        var result = await _handler.Handle(request, cancellationToken);

        // Assert
        using (new AssertionScope())
        {
            result.IsFailure.Should().BeTrue();
            result.Error.Should().Be(CompanyError.NotFound);

            _productRepositoryMock.Verify(
                x => x.AddAsync(It.IsAny<Product>(), cancellationToken),
                Times.Never);

            _unitOfWorkMock.Verify(
                x => x.SaveChangesAsync(cancellationToken),
                Times.Never);
        }
    }

    [Fact]
    public async Task Handle_WhenExceptionOccurs_ShouldReturnFailure()
    {
        // Arrange
        var request = new CreateProductCommand(
            Guid.NewGuid(),
            "Product Name",
            100M);

        _dateTimeProviderMock
            .Setup(x => x.UtcNow)
            .Throws<Exception>();

        var cancellationToken = new CancellationToken();

        // Act
        var result = await _handler.Handle(request, cancellationToken);

        // Assert
        using (new AssertionScope())
        {
            result.IsFailure.Should().BeTrue();

            _productRepositoryMock.Verify(
                x => x.AddAsync(It.IsAny<Product>(), cancellationToken),
                Times.Never);

            _unitOfWorkMock.Verify(
                x => x.SaveChangesAsync(cancellationToken),
                Times.Never);
        }
    }
}
