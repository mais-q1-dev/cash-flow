using Microsoft.Extensions.DependencyInjection.Extensions;

using Rodobens.Libs.Api.Logging;
using Rodobens.Template.WebService.Extensions;

using Serilog.Core;

LoggingLevelSwitch _loggingLevelSwitch = new();

var builder = WebApplication.CreateBuilder(args);
builder.Host.AddRodobensLogging(_loggingLevelSwitch);
builder.Services.TryAddSingleton(_loggingLevelSwitch);

builder.Services.ConfigureServices(builder.Configuration);

var app = builder.Build();

app.Configure();

await app.RunAsync();
