﻿using System.Runtime.Serialization;

namespace Rodobens.Template.WebService.Extensions;

[DataContract]
public record WebServiceProblemDetails
{
    [DataMember]
    public string? Type { get; init; }
    [DataMember]
    public string? Title { get; init; }
    [DataMember]
    public int? Status { get; init; }
    [DataMember]
    public string? Detail { get; init; }
    [DataMember]
    public IDictionary<string, object?>? Extensions { get; init; }
}
