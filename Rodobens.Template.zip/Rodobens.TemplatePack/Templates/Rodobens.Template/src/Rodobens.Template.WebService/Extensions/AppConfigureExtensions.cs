﻿using Rodobens.Libs.Api;
using Rodobens.Template.WebService.Products;

namespace Rodobens.Template.WebService.Extensions;

public static class AppConfigureExtensions
{
    public static void Configure(this WebApplication app)
    {
        app.UseRodobensConfigure(app.Configuration);
        app.UseRouting();
        app.UseEndpoints(endpoints =>
        {
            endpoints.MapRodobensSoapService<IProductSoapService>("Products");
        });
    }
}
