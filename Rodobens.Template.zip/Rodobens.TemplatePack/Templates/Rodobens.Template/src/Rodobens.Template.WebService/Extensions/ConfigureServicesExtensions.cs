﻿using Microsoft.Extensions.DependencyInjection.Extensions;

using Rodobens.Libs.Api;
using Rodobens.Template.Application;
using Rodobens.Template.Infrastructure;
using Rodobens.Template.WebService.Products;

using SoapCore;

namespace Rodobens.Template.WebService.Extensions;

public static class ConfigureServicesExtensions
{
    public static void ConfigureServices(
        this IServiceCollection services,
        ConfigurationManager configuration)
    {
        services.AddRodobensHost(configuration);
        services.AddRodobensApplication(configuration);
        services.AddRodobensInfra(configuration);

        services.AddSoapCore();
        services.TryAddScoped<IProductSoapService, ProductSoapService>();
    }
}