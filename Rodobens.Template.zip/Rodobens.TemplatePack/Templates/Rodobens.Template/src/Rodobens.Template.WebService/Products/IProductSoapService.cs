﻿using System.ServiceModel;

namespace Rodobens.Template.WebService.Products;

[ServiceContract(Namespace = "Rodobens.SoapService.Namespace")]
public interface IProductSoapService
{
    [OperationContract]
    Task<IEnumerable<ProductSoapResponse>> ListProductsAsync();

    [OperationContract]
    Task<Guid> CreateProductAsync(ProductSoapRequest request);
}