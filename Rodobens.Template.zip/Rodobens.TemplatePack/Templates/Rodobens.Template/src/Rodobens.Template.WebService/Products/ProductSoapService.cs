﻿using MediatR;

namespace Rodobens.Template.WebService.Products;

public partial class ProductSoapService : IProductSoapService
{
    private readonly ISender _sender;

    public ProductSoapService(ISender sender)
        => _sender = sender;
}
