﻿using System.Runtime.Serialization;
using System.ServiceModel;

using Rodobens.Template.Application.Products.ListProduct;
using Rodobens.Template.WebService.Extensions;

namespace Rodobens.Template.WebService.Products;

public partial class ProductSoapService
{
    public async Task<IEnumerable<ProductSoapResponse>> ListProductsAsync()
    {
        var result = await _sender.Send(new ListProductQuery(), CancellationToken.None);

        if (!result.IsSuccess)
        {
            var problemDetails = WebServiceExtensions.Problem(result);

            throw new FaultException<WebServiceProblemDetails>(
                problemDetails,
                new FaultReason("An error occurred while processing your request.")
            );
        }

        return result.Value
            .Select(product => new ProductSoapResponse
            { 
                Id = product.Id,
                Name = product.Name,
                Price = product.Price
            })
            .ToList();
    }
}

[DataContract]
public sealed record ProductSoapResponse
{
    [DataMember]
    public Guid Id { get; init; }
    [DataMember]
    public string Name { get; init; } = null!;
    [DataMember]
    public decimal Price { get; init; }
}