﻿using MediatR;

using Microsoft.AspNetCore.Mvc;

using Rodobens.Libs.Domain.Results;
using Rodobens.Template.Application.Products.CreateProduct;
using Rodobens.Template.WebService.Extensions;

using System.Runtime.Serialization;
using System.ServiceModel;

namespace Rodobens.Template.WebService.Products;

public partial class ProductSoapService
{
    public async Task<Guid> CreateProductAsync(ProductSoapRequest request)
    {
        var result = await _sender.Send(request.ToCommand(), CancellationToken.None);

        if (!result.IsSuccess)
        {
            var problemDetails = WebServiceExtensions.Problem(result);

            throw new FaultException<WebServiceProblemDetails>(
                problemDetails,
                new FaultReason("An error occurred while processing your request.")
            );
        }

        return result.Value;
    }
}

[DataContract]
public record ProductSoapRequest
{
    [DataMember]
    public Guid CompanyId { get; init; }
    [DataMember]
    public string Name { get; init; } = null!;
    [DataMember]
    public decimal Price { get; init; }

    public CreateProductCommand ToCommand()
        => new(CompanyId, Name, Price);
}