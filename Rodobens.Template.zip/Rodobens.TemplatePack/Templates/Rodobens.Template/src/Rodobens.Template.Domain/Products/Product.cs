﻿using Rodobens.Libs.Domain.Entities;

namespace Rodobens.Template.Domain.Products;

public class Product : Entity
{
    private Product(
        Guid companyId,
        string name,
        decimal price,
        DateTime createdAt)
    {
        Id = Guid.NewGuid();
        CompanyId = companyId;
        Name = name;
        Price = price;
        CreatedAt = createdAt;
    }

    protected Product() { }

    public Guid Id { get; private set; }
    public Guid CompanyId { get; private set; }
    public string Name { get; private set; } = null!;
    public decimal Price { get; private set; }
    public DateTime CreatedAt { get; private set; }
    public DateTime? UpdatedAt { get; private set; }

    public static Product Create(
        Guid companyId,
        string name,
        decimal price,
        DateTime createdAt)
        => new(companyId, name, price, createdAt);
}
