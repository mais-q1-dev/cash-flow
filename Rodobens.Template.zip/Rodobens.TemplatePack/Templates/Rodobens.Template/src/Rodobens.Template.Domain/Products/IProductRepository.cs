﻿using System.Linq.Expressions;

namespace Rodobens.Template.Domain.Products;

public interface IProductRepository
{
    Task AddAsync(Product product, CancellationToken cancellationToken);
    Task<IEnumerable<Product>> GetAll(CancellationToken cancellationToken);
}
