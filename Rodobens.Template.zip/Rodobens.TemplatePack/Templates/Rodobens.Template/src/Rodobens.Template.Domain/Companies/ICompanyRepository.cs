﻿namespace Rodobens.Template.Domain.Companies;

public interface ICompanyRepository
{
    Task<bool> ExistsAsync(Guid id, CancellationToken cancellationToken);
}
