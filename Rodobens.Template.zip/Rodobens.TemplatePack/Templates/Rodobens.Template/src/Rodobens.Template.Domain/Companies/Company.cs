﻿using Rodobens.Libs.Domain.Entities;

namespace Rodobens.Template.Domain.Companies;

public class Company : Entity
{
    private Company(
        Guid id,
        string name,
        DateTime createdAt,
        DateTime? updatedAt)
    {
        Id = id;
        Name = name;
        CreatedAt = createdAt;
        UpdatedAt = updatedAt;
    }

    protected Company() { }

    public Guid Id { get; private set; }
    public string Name { get; private set; } = null!;
    public DateTime CreatedAt { get; private set; }
    public DateTime? UpdatedAt { get; private set; }

    public static Company Create(
        Guid id,
        string name,
        DateTime createdAt,
        DateTime? updatedAt)
        => new(id, name, createdAt, updatedAt);
}