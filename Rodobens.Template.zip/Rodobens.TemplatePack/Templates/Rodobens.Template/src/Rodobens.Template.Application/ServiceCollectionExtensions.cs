﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

using Rodobens.Libs.Application;

namespace Rodobens.Template.Application;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddRodobensApplication(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        services.AddRodobensMediatR(typeof(ServiceCollectionExtensions).Assembly);

        return services;
    }
}
