﻿using Rodobens.Libs.Application.Messaging;
using Rodobens.Template.Application.Products.Common;

namespace Rodobens.Template.Application.Products.ListProduct;

public sealed record ListProductQuery : IQuery<IEnumerable<ProductResponse>>;
