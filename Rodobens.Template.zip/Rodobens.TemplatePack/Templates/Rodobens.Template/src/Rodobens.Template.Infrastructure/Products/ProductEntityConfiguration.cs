﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

using Rodobens.Template.Domain.Companies;
using Rodobens.Template.Domain.Products;

namespace Rodobens.Template.Infrastructure.Products;

public class ProductEntityConfiguration : IEntityTypeConfiguration<Product>
{
    public void Configure(EntityTypeBuilder<Product> builder)
    {
        builder.ToTable("Products");

        builder.HasKey(product => product.Id);

        builder.Property(product => product.CompanyId)
            .IsRequired();

        builder.HasOne<Company>()
            .WithMany()
            .HasForeignKey(product => product.CompanyId);

        builder.Property(product => product.Name)
            .IsRequired()
            .HasMaxLength(100);

        builder.Property(product => product.Price)
            .IsRequired();

        builder.Property(product => product.CreatedAt)
            .IsRequired();

        builder.Property(product => product.UpdatedAt);
    }
}
