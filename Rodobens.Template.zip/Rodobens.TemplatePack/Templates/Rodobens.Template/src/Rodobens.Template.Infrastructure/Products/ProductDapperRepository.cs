﻿

using Dapper;

using Rodobens.Template.Domain.Products;
using Rodobens.Template.Infrastructure.SqlServer2005Prefix;

namespace Rodobens.Template.Infrastructure.Products
{
    public class ProductDapperRepository : IProductRepository
    {
        private readonly SqlServer2005PrefixDapperContext _dapperContext;

        public ProductDapperRepository(SqlServer2005PrefixDapperContext dapperContext)
            => _dapperContext = dapperContext;

        public async Task AddAsync(Product product, CancellationToken cancellationToken)
        {
            using var connection = _dapperContext.Connection;

            string sql = @"INSERT INTO Products
                        (Id, CompanyId, Name, Price, CreatedAt, UpdatedAt)
                    VALUES
                        (@Id, @CompanyId, @Name, @Price, @CreatedAt, null)";

            await connection.ExecuteAsync(sql, product);
        }

        public async Task<IEnumerable<Product>> GetAll(CancellationToken cancellationToken)
        {
            using var connection = _dapperContext.Connection;

            string sql = "SELECT * FROM Products ORDER BY Name";

            return await connection.QueryAsync<Product>(sql);
        }
    }
}
