﻿
using Microsoft.EntityFrameworkCore;

using Rodobens.Template.Domain.Companies;
using Rodobens.Template.Infrastructure.SQLite;

namespace Rodobens.Template.Infrastructure.Companies;

public class CompanyRepository : ICompanyRepository
{
    private readonly SQLiteDbContext _dbContext;

    public CompanyRepository(SQLiteDbContext dbContext)
        => _dbContext = dbContext;

    public async Task<bool> ExistsAsync(Guid id, CancellationToken cancellationToken)
        => await _dbContext.Companies.AnyAsync(company => company.Id == id, cancellationToken);
}